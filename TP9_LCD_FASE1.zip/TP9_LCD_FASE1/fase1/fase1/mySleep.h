#ifndef MYSLEEP_H
#define MYSLEEP_H



	void mySleep(int sleepMs);
#endif